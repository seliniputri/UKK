<?php include 'koneksi.php'; include 'header.php';

$per_page = 5; // Jumlah data yang akan ditampilkan per halaman

// Mendapatkan nomor halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_page;

// Membuat query SQL untuk mengambil data
$sql = "SELECT barang.*, kategori.nama_kategori 
        FROM barang 
        JOIN kategori ON barang.id_kategori = kategori.id_kategori";

$where = [];

if (isset($_GET['cari']) && $_GET['cari'] != '') {
    $cari = $koneksi->real_escape_string($_GET['cari']);
    $where[] = "barang.nama_barang LIKE '%$cari%'";
}

if (isset($_GET['kategori']) && $_GET['kategori'] != '') {
    $kategori = $koneksi->real_escape_string($_GET['kategori']);
    $where[] = "barang.id_kategori = '$kategori'";
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

// Menambahkan limit untuk pagination
$sql .= " LIMIT $start, $per_page";

$result = $koneksi->query($sql);

// Menghitung total data
$total_sql = "SELECT COUNT(*) AS total FROM barang";
if (!empty($where)) {
    $total_sql .= " WHERE " . implode(' AND ', $where);
}
$total_result = $koneksi->query($total_sql);
$total_data = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_data / $per_page);

?>

<style>
    body {
        background-color: #f7f9fc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333;
    }

    h2 {
        margin-top: 30px;
        color: #2c3e50;
        text-align: center;
        font-weight: bold;
        font-size: 24px;
    }

    .search-container {
        width: 95%;
        margin: 20px auto;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }

    .search-container input,
    .search-container select {
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        background-color: #f1f3f6;
        color: #2c3e50;
        font-size: 14px;
    }

    .search-container button {
        padding: 10px 16px;
        border-radius: 6px;
        border: none;
        background-color: #3498db;
        color: white;
        font-weight: bold;
        font-size: 14px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .search-container button:hover {
        background-color: #2980b9;
    }

    .table {
        width: 95%;
        margin: 30px auto;
        border-collapse: collapse;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        border-radius: 8px;
        background-color: white;
    }

    .table thead th {
        background-color: #3498db;
        color: white;
        text-align: center;
        padding: 14px;
        font-size: 16px;
        font-weight: bold;
    }

    .table tbody td {
        text-align: center;
        padding: 12px;
        color: #2c3e50;
        font-size: 14px;
    }

    .table tbody tr:nth-child(even) {
        background-color: #ecf0f1;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #ffffff;
    }

    .table tbody tr:hover {
        background-color: #f1c40f;
        transition: background 0.3s ease;
    }

    .btn {
        padding: 8px 16px;
        text-decoration: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
    }

    .btn-warning {
        background-color: #f39c12;
        color: white;
    }

    .btn-danger {
        background-color: #e74c3c;
        color: white;
    }

    .btn-warning:hover {
        background-color: #f1c40f;
    }

    .btn-danger:hover {
        background-color: #c0392b;
    }

    .btn-sm {
        font-size: 13px;
        padding: 6px 12px;
    }

    .aksi-col {
        display: flex;
        justify-content: center;
        gap: 8px;
    }
</style>

<h2>Daftar Barang</h2>

<!-- Tombol Export ke Excel -->
<div class="export-container">
    <a href="export_excel.php" class="btn btn-sm btn-success">Export to Excel</a>
</div>




<div class="search-container">
    <form method="GET" action="">
        <input type="text" name="cari" placeholder="Cari nama barang..." 
               value="<?= isset($_GET['cari']) ? htmlspecialchars($_GET['cari']) : '' ?>">

        <select name="kategori">
            <option value="">Semua Kategori</option>
            <?php
            $kategori_q = $koneksi->query("SELECT * FROM kategori");
            while ($kat = $kategori_q->fetch_assoc()) {
                $selected = (isset($_GET['kategori']) && $_GET['kategori'] == $kat['id_kategori']) ? 'selected' : '';
                echo "<option value='{$kat['id_kategori']}' $selected>{$kat['nama_kategori']}</option>";
            }
            ?>
        </select>

        <button type="submit">Cari</button>
    </form>
</div>

<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Stok</th>
            <th>Harga</th>
            <th>Tanggal Masuk</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = $start + 1;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$no}</td>
                        <td>{$row['nama_barang']}</td>
                        <td>{$row['nama_kategori']}</td>
                        <td>{$row['jumlah_stok']}</td>
                        <td>Rp. " . number_format($row['harga_barang'], 0, ',', '.') . "</td>
                        <td>{$row['tanggal_masuk']}</td>
                        <td class='aksi-col'>
                            <a href='edit_barang.php?id={$row['id_barang']}' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='hapus_barang.php?id={$row['id_barang']}' class='btn btn-danger btn-sm' 
                               onclick=\"return confirm('Yakin ingin menghapus barang ini?')\">Hapus</a>
                        </td>
                    </tr>";
                $no++;
            }
        } else {
            echo "<tr><td colspan='7' style='text-align:center;'>Data tidak ditemukan.</td></tr>";
        }
        ?>
    </tbody>
</table>

<!-- Pagination -->
<div class="pagination">
    <ul style="list-style-type: none; display: flex; justify-content: center;">
        <?php if ($page > 1): ?>
            <li><a href="?page=1<?= isset($_GET['cari']) ? '&cari=' . $_GET['cari'] : '' ?><?= isset($_GET['kategori']) ? '&kategori=' . $_GET['kategori'] : '' ?>" class="btn btn-sm">First</a></li>
            <li><a href="?page=<?= $page - 1 ?><?= isset($_GET['cari']) ? '&cari=' . $_GET['cari'] : '' ?><?= isset($_GET['kategori']) ? '&kategori=' . $_GET['kategori'] : '' ?>" class="btn btn-sm">Prev</a></li>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <li><a href="?page=<?= $i ?><?= isset($_GET['cari']) ? '&cari=' . $_GET['cari'] : '' ?><?= isset($_GET['kategori']) ? '&kategori=' . $_GET['kategori'] : '' ?>" class="btn btn-sm"><?= $i ?></a></li>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <li><a href="?page=<?= $page + 1 ?><?= isset($_GET['cari']) ? '&cari=' . $_GET['cari'] : '' ?><?= isset($_GET['kategori']) ? '&kategori=' . $_GET['kategori'] : '' ?>" class="btn btn-sm">Next</a></li>
            <li><a href="?page=<?= $total_pages ?><?= isset($_GET['cari']) ? '&cari=' . $_GET['cari'] : '' ?><?= isset($_GET['kategori']) ? '&kategori=' . $_GET['kategori'] : '' ?>" class="btn btn-sm">Last</a></li>
        <?php endif; ?>
    </ul>
</div>

<?php include 'footer.php'; ?>
