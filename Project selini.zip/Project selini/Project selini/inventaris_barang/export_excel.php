<?php
include 'koneksi.php';

// Query untuk mengambil data barang
$sql = "SELECT barang.*, kategori.nama_kategori 
        FROM barang 
        JOIN kategori ON barang.id_kategori = kategori.id_kategori";
        
if (isset($_GET['cari']) && $_GET['cari'] != '') {
    $cari = $koneksi->real_escape_string($_GET['cari']);
    $sql .= " WHERE barang.nama_barang LIKE '%$cari%'";
}

$result = $koneksi->query($sql);

// Menyiapkan header untuk file Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="data_barang.xls"');
header('Cache-Control: max-age=0');

// Membuka output stream untuk menulis data Excel
echo "<table border='1'>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Stok</th>
            <th>Harga</th>
            <th>Tanggal Masuk</th>
        </tr>";

// Menulis data ke dalam file Excel
$no = 1;
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$no}</td>
            <td>{$row['nama_barang']}</td>
            <td>{$row['nama_kategori']}</td>
            <td>{$row['jumlah_stok']}</td>
            <td>Rp. " . number_format($row['harga_barang'], 0, ',', '.') . "</td>
            <td>{$row['tanggal_masuk']}</td>
          </tr>";
    $no++;
}

echo "</table>";
exit;
?>
