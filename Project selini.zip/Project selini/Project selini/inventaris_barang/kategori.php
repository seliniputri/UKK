<?php
include 'koneksi.php';
include 'header.php';

// Tambah kategori
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_kategori'];
    $koneksi->query("INSERT INTO kategori (nama_kategori) VALUES ('$nama')");
}

// Hapus kategori
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $koneksi->query("DELETE FROM kategori WHERE id_kategori = $id");
}

$kategori = $koneksi->query("SELECT * FROM kategori ORDER BY id_kategori ASC"); // urutkan berdasarkan ID
?>

<h2 class="text-center my-4">Kategori</h2>

<form method="POST" class="row g-3 mb-4 w-75 mx-auto">
    <div class="col-md-8">
        <input type="text" name="nama_kategori" class="form-control" placeholder="Nama Kategori" required>
    </div>
    <div class="col-md-4">
        <button type="submit" name="tambah" style="background-color: #2980b9; color: white; border: none;" class="btn w-100">
            Tambah Kategori
        </button>
    </div>
</form>

<table class="table table-striped table-hover table-bordered align-middle text-center shadow-sm w-75 mx-auto">
    <thead class="table-primary">
        <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Kategori</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $no = 1; // Nomor urut
        while ($row = $kategori->fetch_assoc()) { ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                <td>
                    <a href="?hapus=<?= $row['id_kategori'] ?>" 
                       onclick="return confirm('Hapus kategori ini?')" 
                       class="btn btn-sm btn-danger">
                        Hapus
                    </a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<?php include 'footer.php'; ?>
